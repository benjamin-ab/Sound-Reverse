#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <ctype.h>

#include    <sndfile.h>

#include    "common.h"

#define     BUFFER_LEN  (1 << 16)

static void concat_data_fp(SNDFILE *wfile, SNDFILE *rofile, int channels);
static void concat_data_int(SNDFILE *wfile, SNDFILE *rofile, int channels);

int main(int argc, char *argv []) {
    const char *infilename, *outfilename;
    SNDFILE *infile, *outfile;
    SF_INFO sfinfo_in, sfinfo_out;
    void (*func)(SNDFILE*, SNDFILE*, int);

    if ((infile = calloc(1, sizeof(SNDFILE*))) == NULL) {
        printf("\nError : Malloc failed.\n\n");
        exit(1);
    };


    memset(&sfinfo_in, 0, sizeof(sfinfo_in));

    if ((infile = sf_open(argv[1], SFM_READ, &sfinfo_in)) == NULL) {
        printf("\nError : failed to open file '%s'.\n\n", argv[1]);
        exit(1);
    };

    sfinfo_out = sfinfo_in;

    if (sfinfo_in.channels != sfinfo_out.channels) {
        printf("\nError : File '%s' has %d channels (should have %d).\n\n",
                argv[1], sfinfo_in.channels, sfinfo_out.channels);
        exit(1);
    };

    if ((outfile = sf_open(outfilename, SFM_WRITE, &sfinfo_out)) == NULL) {
        printf("\nError : Not able to open input file %s.\n", outfilename);
        puts(sf_strerror(NULL));
        exit(1);
    };
    
    printf("%s" , sfinfo_in);

//    if ((sfinfo_out.format & SF_FORMAT_SUBMASK) == SF_FORMAT_DOUBLE
//            || (sfinfo_out.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT)
//        func = concat_data_fp;
//    else
//        func = concat_data_int;
//
//    func(outfile, infile, sfinfo_out.channels);
//    sf_close(infile);

    //sf_close(outfile);
    free(infile);

    return 0;
} /* main */

static void concat_data_fp(SNDFILE *wfile, SNDFILE *rofile, int channels) {
    static double data[BUFFER_LEN];
    int frames, readcount;

    frames = BUFFER_LEN / channels;
    readcount = frames;

    sf_seek(wfile, 0, SEEK_END);

    while (readcount > 0) {
        readcount = sf_readf_double(rofile, data, frames);
        sf_writef_double (wfile, data, readcount) ;
    };

    return;
} /* concat_data_fp */

static void concat_data_int(SNDFILE *wfile, SNDFILE *rofile, int channels) {
    static int data[BUFFER_LEN];
    int frames, readcount;

    frames = BUFFER_LEN / channels;
    readcount = frames;

    sf_seek(wfile, 0, SEEK_END);

    while (readcount > 0) {
        readcount = sf_readf_int(rofile, data, frames);
        sf_writef_int(wfile, data, readcount);
    };

    return;
} /* concat_data_int */
